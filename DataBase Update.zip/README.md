Global Account:
	Username: admin
	Password: pass

This Database requres that the AssignedGear model under game to have the gear_ID set up as a ForeignKey with cascade.